SUNBOUND Alpha 0.10.0

แตก ZIP แล้วเปิด SUNBOUND/index.html ด้วย Chrome หรือ Edge
เล่นคนเดียว ไม่ต้องติดตั้ง Node.js
Co-op และบัญชีออนไลน์ใช้ชุดเซิร์ฟเวอร์แยก
