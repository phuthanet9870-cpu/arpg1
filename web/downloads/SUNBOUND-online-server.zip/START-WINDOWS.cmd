@echo off
cd /d "%~dp0"
call npm ci
call npm start
pause
